<head>
<script type="text/javascript"
 src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript">

$(document).ready(function() {
        $('#input').keyup(function(){
            
          var limit = parseInt($(this).attr('maxlength'));           
          var text = $(this).html();
          var chars = text.length;
            
            if(chars >= limit){             
                var new_text = text.substr(0,limit);
                $(this).html(new_text);           
            }
        });
});
  
</script>
</head>
<body>
    
</body>


<?php

class Login{
 
    private $req;
    
    public function __construct(){
        session_start();     
        $this->req = $_REQUEST;
        
 
        switch(true){//             reg = Ansicht | register = registrierung
            case isset($this->req['reg']):$this->toDisplayRegister();
                                              break;
            case isset($this->req['register']):$this->setRegister(); 
                                              break;
            case isset($this->req['logout']):$this->setLogout();   
                                              break;
            case isset($this->req['login']):$this->checkPassword(); 
                                              break;
            default:
                    if(isset($_SESSION['id_user']))$this->toDisplayMessage();
                         else $this->toDisplayLogin();                                             
        }//end switch   
    }
    
    
    
    
 
    
    
private function getUserName(){ // Den Namen der aktuellen SESSION user ID anzeigen und irgendwo nutzen
    return MODEL::getUserName($_SESSION['id_user']);
    
}


    
private function checkPassword(){
    $name = $this->req['name']; // Name bei Anmeldung
    $hash = hash('sha512',$this->req['pass']);    
    $id = Model::getUserPassID($name, $hash); // Entweder kommt eine ID Zurück oder ein false
    
    
    if($id){ // Userzugang richtig
        $_SESSION['id_user'] = $id;
        $_SESSION['time'] = time(); // Siehe Controller
        
        
        header("Location: index.php");
        exit;
    }else{ // Userzugang falsch
        echo "<br>Ah! Ah! Ah! Du hast das Zauberwort nicht gesagt.<br><p>";
        $this->toDisplayLogin();
    }
}    
    
private function setLogout(){

    session_destroy();
    header("Location: start.php");
    exit;
}
    
private function setRegister(){
    $name = $this->req['name']; //Name aus Formular
    
    if($this->req['pass'] != $this->req['passw']){
        echo "Passwortwiederholung stimmt nicht<br>";
        $this->toDisplayRegister();
        return false; // Abbruch, keine weitere Ausgabe
    }else
    $hash = hash('sha512', $this->req['pass']);
    $id = MODEL::setUserIntoDB($name,$hash); // Bei Erfolg Userid
    
    if($id){
        $_SESSION['id_user'] = $id; // User registriert
        header("Location: index.php"); //Sprung zur Hauptseite mit aktivierter Session
        exit;
    }
    else{ // Username existiert bereits
        echo "User existiert bereits<br>";
        $this->toDisplayRegister();
        
    }
   
}




private function toDisplayMessage(){ // Messagefenster
     
    echo "Willkommen ".$this->getUserName()."<br>";

    echo '<div id="input" minlength="2" maxlength="210" contenteditable="true">  </div>       
          

            <!-- Senden Button und Smileys -->
            <button id="send">Senden</button><br>        
             <li><img onclick="showImg(this.src)" src="img/laught.png" style="width:18px;height:18px;" /></li> <!-- this.src = selbstreferenz auf das src danach (img) -->
             <li><img onclick="showImg(this.src)" src="img/smile.png" style="width:18px;height:18px;" /></li>                  
            </div>';
    
    
    

    echo'<form action="class/class_File.inc.php" method="post" enctype="multipart/form-data">
        <p>Wählen Sie eine Datei aus:<br>
        <input name="Datei" type="file" size="40">
        </p>
        <input type="submit" name="Submit" value="Senden">
        </form>';     


    echo '<a href="index.php?logout=true">Logout</a>';
    

    
    }   
    
    
private function toDisplayLogin(){ // Loginfenster
        echo  'Login / <a href="?reg=true">Registrieren</a>   <br>
              <form id="login">
              <input type="text" placeholder="Name" name="name"><br>
              <input type="text" placeholder="Passwort" name="pass"><br>
              <input type="submit" value="login" name="login">
              </form>';
              
              
    
    
}
private function toDisplayRegister(){ // Registerfenster
         echo '<a href="start.php">Login</a> / Registrieren   <br>
              <form>
              <input type="text" placeholder="Name" name="name"><br>
              <input type="text" placeholder="Passwort" name="pass"><br>
              <input type="text" placeholder="Passwortwiederholung" name="passw"><br>
              <input type="submit" value="registration" name="register"> 
              </form>';

}




}

