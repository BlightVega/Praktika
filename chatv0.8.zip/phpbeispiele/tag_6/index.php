<!DOCTYPE html>
<html>
    
    <head>
        <title>Chat</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        
    </head>
    <body>

        
        <h1>LiveChat</h1>

        <div id="message">   
           
        </div>
        
        <?php
        
        spl_autoload_register(function($class_name){
        include "class/class_".$class_name.".inc.php";
        include "html/script_Emoji.html";

        });

        new Login();

        
        
        ?>

        <script>
            
            var m = document.getElementById("message");
            var s = document.getElementById("send"); //Selektor
            var inp = document.getElementById("input");
            
            
            
            
            function myRead()
            {
                var http = new XMLHttpRequest();
                // lade Datei auf Server synchron / true = asynchrone
                http.open('get','class/autoloader.php', true);
                http.onreadystatechange = function()
                {
                    if(http.readyState === 4 && http.status === 200)
                    {
                        m.innerHTML = http.responseText; // Hier mit createElement Ansetzen für Traffic Reduzierung.          
                        m.scrollTop = 10000;
                    }
                    if(http.status === 404)
                    {
                        alert("File not found");
                    }
                };
                http.send(); //Ajax aufbau
                

                
            }

               


            function myWrite(message){ // An Server senden
                var httpsend = new XMLHttpRequest();
                httpsend.open('get','class/autoloader.php?input='+message , true);
                httpsend.send();
            }
            
            /* Hauptprogram Anweisungen */
            myRead();
            
            setInterval("myRead()", 2000); //Alle 2sec. aktualisieren
            
            /* Events */
            s.onclick = function(){
                myWrite(inp.innerHTML); // innerHTML wenn ich ein div zur Texteingabe nutze. TEXT von INPUT auf CHAT
                inp.innerHTML = ""; //löschen der Eingabe nach betätigung des "send" button
                

            };
            

            
        </script>
           
    </body>
</html>
