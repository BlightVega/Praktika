<!DOCTYPE html>
<html>
    <head>
        <title>Chat</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="../css/start.css">
    </head>
    <body>
        <h1>Administrator Login</h1>
        
        <div id="message">   
           
        </div>
        
        <?php
        
        spl_autoload_register(function($class_name){
        include "../class/class_".$class_name.".inc.php";
    
        });
        
        new Login();

        ?>
        

 
    </body>
</html>

